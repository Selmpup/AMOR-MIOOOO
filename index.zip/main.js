function closePopup() {
  document.getElementById("popup").style.display = "none";
}

function reopenPopup() {
  document.getElementById("popup").style.display = "block";
}
